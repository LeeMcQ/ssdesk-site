# Translation quality test — dry run (no model)

**50 of 50 sentences correct** (100 %) · 0.0 s

| Kind | Correct |
|---|---|
| adventist | 15 / 15 |
| names | 8 / 8 |
| slang | 14 / 14 |
| mixed | 2 / 2 |
| sermon | 6 / 6 |
| bible | 5 / 5 |

Names kept by marker: 26 · retried inline: 0

| | Kind | Afrikaans | Shown in English | Reference | Note |
|---|---|---|---|---|---|
| ✔ | adventist | Ons aanbid God op die Sabbat, die sewende dag van die week. | Ons aanbid God op die Sabbath, die sewende dag van die week. | We worship God on the Sabbath, the seventh day of the week. |  · sent: Ons aanbid God op die 9301, die sewende dag van die week. |
| ✔ | adventist | Die Sabbatskool begin om nege-uur. | Die Sabbath School begin om nege-uur. | Sabbath School starts at nine o'clock. |  · sent: Die 9301 begin om nege-uur. |
| ✔ | adventist | Ellen G. White het baie oor gesondheid geskryf. | Ellen G. White het baie oor gesondheid geskryf. | Ellen G. White wrote a lot about health. |  · sent: 9301 het baie oor gesondheid geskryf. |
| ✔ | adventist | Die Gees van die Profesie lei ons na die Bybel. | Die Spirit of Prophecy lei ons na die Bybel. | The Spirit of Prophecy leads us to the Bible. |  · sent: Die 9301 lei ons na die Bybel. |
| ✔ | adventist | Ons wag op die wederkoms van Jesus Christus. | Ons wag op die Second Coming van Jesus Christus. | We are waiting for the Second Coming of Jesus Christ. |  · sent: Ons wag op die 9301 van Jesus Christus. |
| ✔ | adventist | Die drie engele se boodskappe moet aan die hele wêreld verkondig word. | Die three angels' messages moet aan die hele wêreld verkondig word. | The three angels' messages must be proclaimed to the whole world. |  · sent: Die 9301 moet aan die hele wêreld verkondig word. |
| ✔ | adventist | Na die preek hou ons die Nagmaal en voetewassing. | Na the sermon hou ons die Lord's Supper en foot washing. | After the sermon we hold the Lord's Supper and foot washing. |  · sent: Na 9301 hou ons die 9302 en 9303. |
| ✔ | adventist | Bring asseblief jou tiendes en offergawes na die Here. | Bring asseblief jou tithes en offerings na the Lord. | Please bring your tithes and offerings to the Lord. |  · sent: Bring asseblief jou 9301 en 9302 na 9303. |
| ✔ | adventist | Die Padvinders en Avontuurders bied vanmiddag 'n program aan. | Die Pathfinders en Adventurers bied vanmiddag 'n program aan. | The Pathfinders and Adventurers present a programme this afternoon. |  · sent: Die 9301 en 9302 bied vanmiddag 'n program aan. |
| ✔ | adventist | Christus dien vir ons as Hoëpriester in die hemelse heiligdom. | Christus dien vir ons as High Priest in die hemelse sanctuary. | Christ serves for us as High Priest in the heavenly sanctuary. |  · sent: Christus dien vir ons as 9301 in die hemelse 9302. |
| ✔ | adventist | Die Heilige Gees gee ons krag om te getuig. | Die Holy Spirit gee ons krag om te getuig. | The Holy Spirit gives us strength to witness. |  · sent: Die 9301 gee ons krag om te getuig. |
| ✔ | adventist | Die Sewendedag-Adventiste Kerk is oor die hele wêreld. | Die Seventh-day Adventist Church is oor die hele wêreld. | The Seventh-day Adventist Church is all over the world. |  · sent: Die 9301 is oor die hele wêreld. |
| ✔ | adventist | Laat ons ons koppe buig vir gebed. | Let us bow our heads in prayer. | Let us bow our heads for prayer. |  · sent: 9301. |
| ✔ | adventist | Ons lees vanoggend uit Daniël hoofstuk twee. | Ons lees vanoggend uit Daniël hoofstuk 2. | This morning we read from Daniel chapter two. |  · sent: Ons lees vanoggend uit Daniël hoofstuk 2. |
| ✔ | adventist | Broers en susters, die Here is getrou. | Broers en susters, the Lord is getrou. | Brothers and sisters, the Lord is faithful. |  · sent: Broers en susters, 9301 is getrou. |
| ✔ | names | Ons verwelkom vandag pastoor Van der Merwe en sy vrou. | Ons verwelkom vandag pastor Van der Merwe en sy vrou. | Today we welcome Pastor Van der Merwe and his wife. |  · sent: Ons verwelkom vandag 9301 9302 en sy vrou. |
| ✔ | names | Broer Fortuin doen vandag die Skriflesing. | Broer Fortuin doen vandag die Scripture reading. | Brother Fortuin does the Scripture reading today. |  · sent: Broer 9301 doen vandag die 9302. |
| ✔ | names | Suster Swart het die blomme vir die kerk gebring. | Suster Swart het die blomme vir die kerk gebring. | Sister Swart brought the flowers for the church. |  · sent: Suster 9301 het die blomme vir die kerk gebring. |
| ✔ | names | Die kerk in Malmesbury hou volgende Sabbat 'n doop. | Die kerk in Malmesbury hou volgende Sabbath 'n doop. | The church in Malmesbury holds a baptism next Sabbath. |  · sent: Die kerk in 9301 hou volgende 9302 'n doop. |
| ✔ | names | Ouderling De Wet bid vir die siekes. | Elder De Wet bid vir die siekes. | Elder De Wet prays for the sick. |  · sent: 9301 9302 bid vir die siekes. |
| ✔ | names | Ons sê saam: Amen. | Ons sê saam: Amen. | Together we say: Amen. |  · sent: Ons sê saam: 9301. |
| ✔ | names | Ná die diens is daar 'n braai by die saal. | Ná die diens is daar 'n braai by die saal. | After the service there is a braai at the hall. |  · sent: Ná die diens is daar 'n 9301 by die saal. |
| ✔ | names | Broer Koopman neem die kollekte op. | Broer Koopman neem die kollekte op. | Brother Koopman takes up the collection. |  · sent: Broer 9301 neem die kollekte op. |
| ✔ | slang | Ek's so bly djy's hie vandag. | Ek is so bly jy is hier vandag. | I'm so glad you're here today. |  · sent: Ek is so bly jy is hier vandag. |
| ✔ | slang | Die laaities moet asseblief stil sit in die kerk. | Die kinders moet asseblief stil sit in die kerk. | The children must please sit quietly in the church. |  · sent: Die kinders moet asseblief stil sit in die kerk. |
| ✔ | slang | Ons gaan nou-nou sing, so maak julle gereed. | Ons gaan binnekort sing, so maak julle gereed. | We are going to sing soon, so get ready. |  · sent: Ons gaan binnekort sing, so maak julle gereed. |
| ✔ | slang | Sjoe, dit was 'n lekker diens vandag! | Wow, dit was 'n lekker diens vandag! | Wow, that was a lovely service today! |  · sent: 9301, dit was 'n lekker diens vandag! |
| ✔ | slang | Ag nee, die krag is weer af. | Nee, die krag is weer af. | Oh no, the power is off again. |  · sent: Nee, die krag is weer af. |
| ✔ | slang | My bru, God het jou lief. | My vriend, God het jou lief. | My friend, God loves you. |  · sent: My vriend, God het jou lief. |
| ✔ | slang | Dit issie maklik nie, maar God is goed. | Dit is nie maklik nie, maar God is goed. | It is not easy, but God is good. |  · sent: Dit is nie maklik nie, maar God is goed. |
| ✔ | slang | Kom ons kuier ná kerk by die tannie se huis. | Kom ons kuier ná kerk by die tannie se huis. | Let's visit at auntie's house after church. |  · sent: Kom ons kuier ná kerk by die tannie se huis. |
| ✔ | slang | Hy het mos gesê hy sal kom, nè? | Hy het gesê hy sal kom? | He did say he would come, right? |  · sent: Hy het gesê hy sal kom? |
| ✔ | slang | Jislaaik, die Here is darem goed vir ons! | Wow, the Lord is darem goed vir ons! | Wow, the Lord is really good to us! |  · sent: 9301, 9302 is darem goed vir ons! |
| ✔ | slang | Ek wiet nie wat om te sê nie. | Ek weet nie wat om te sê nie. | I don't know what to say. |  · sent: Ek weet nie wat om te sê nie. |
| ✔ | slang | Moenie skinder oor jou broer nie. | Moenie skinder oor jou broer nie. | Don't gossip about your brother. |  · sent: Moenie skinder oor jou broer nie. |
| ✔ | slang | Die tjommies kom almal saam kerk toe. | Die vriende kom almal saam kerk toe. | The friends are all coming to church together. |  · sent: Die vriende kom almal saam kerk toe. |
| ✔ | slang | Daar's 'n bakkie voor die kerk geparkeer. | Daar is 'n bakkie voor die kerk geparkeer. | There's a bakkie parked in front of the church. |  · sent: Daar is 'n 9301 voor die kerk geparkeer. |
| ✔ | mixed | Ons moet net believe dat God in control is. | Ons moet net believe dat God in control is. | We just have to believe that God is in control. |  · sent: Ons moet net believe dat God in control is. |
| ✔ | mixed | Die Here het 'n plan vir jou life. | The Lord het 'n plan vir jou life. | The Lord has a plan for your life. |  · sent: 9301 het 'n plan vir jou life. |
| ✔ | sermon | Geloof is nie 'n gevoel nie, dit is 'n besluit. | Geloof is nie 'n gevoel nie, dit is 'n besluit. | Faith is not a feeling, it is a decision. |  · sent: Geloof is nie 'n gevoel nie, dit is 'n besluit. |
| ✔ | sermon | God vergewe ons wanneer ons ons sondes bely. | God vergewe ons wanneer ons ons sondes bely. | God forgives us when we confess our sins. |  · sent: God vergewe ons wanneer ons ons sondes bely. |
| ✔ | sermon | Elke dag moet ons tyd maak om die Bybel te lees en te bid. | Elke dag moet ons tyd maak om die Bybel te lees en te bid. | Every day we must make time to read the Bible and pray. |  · sent: Elke dag moet ons tyd maak om die Bybel te lees en te bid. |
| ✔ | sermon | Jesus het die siekes genees en die armes gehelp. | Jesus het die siekes genees en die armes gehelp. | Jesus healed the sick and helped the poor. |  · sent: Jesus het die siekes genees en die armes gehelp. |
| ✔ | sermon | Ons hoop is in die beloftes van God. | Ons hoop is in die beloftes van God. | Our hope is in the promises of God. |  · sent: Ons hoop is in die beloftes van God. |
| ✔ | sermon | Volgende week is daar 'n jeugkamp in die berge. | Volgende week is daar 'n jeugkamp in die berge. | Next week there is a youth camp in the mountains. |  · sent: Volgende week is daar 'n jeugkamp in die berge. |
| ✔ | bible | Want so lief het God die wêreld gehad, dat Hy sy eniggebore Seun gegee het, sodat elkeen wat in Hom glo, nie verlore mag gaan nie, maar die ewige lewe kan hê. | For God so loved the world, that he gave his one and only Son, that whoever believes in him should not perish, but have eternal life. | @John 3:16 |  |
| ✔ | bible | Die Here is my Herder, niks sal my ontbreek nie. | The LORD is my shepherd: I shall lack nothing. | @Psalms 23:1 |  |
| ✔ | bible | Gedenk die sabbatdag, dat jy dit heilig. | "Remember the Sabbath day, to keep it holy. | @Exodus 20:8 |  |
| ✔ | bible | Want so lief het God die wêreld gehad dat Hy sy eniggebore Seun gegee het | For God so loved the world, that he gave his one and only Son, that whoever believes in him should not perish, but have eternal life. | @John 3:16 |  |
| ✔ | bible | Want God het die wêreld so lief gehad dat Hy sy Seun gestuur het om ons te red. | Want God het die wêreld so lief gehad dat Hy sy Seun gestuur het om ons te red. | God loved the world so much that he sent his Son to save us. |  · sent: Want God het die wêreld so lief gehad dat Hy sy Seun gestuur het om ons te red. |
